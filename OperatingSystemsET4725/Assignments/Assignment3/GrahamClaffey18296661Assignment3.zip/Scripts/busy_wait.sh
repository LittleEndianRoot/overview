#! /bin/bash
# Meaningless program used called busy_wait to simulate some activity

while true; do
	(( x++ ))
done
